import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import Header from './layout/Header'
import Categories from './pages/Categories'
import Users from './pages/Users'
import AddCategory from './pages/AddCategory'
import AddUser from './pages/AddUser'


class App extends React.Component {
    render() {
        return (
            <>
                <BrowserRouter>
                    <Header />
                    <Routes>
                        <Route path='/listCategories' element={<Categories/>} />
                        <Route path='/listUsers' element={<Users/>} />
                        <Route path='/addCategory' element={<AddCategory/>} />
                        <Route path='/addUser' element={<AddUser/>} />
                    </Routes>
                </BrowserRouter>
            </>
        );
    }
}
export default App;