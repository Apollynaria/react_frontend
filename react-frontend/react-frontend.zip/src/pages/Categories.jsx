import React from 'react';

// импорт компонента CategoryData
import Category from '../components/category/Category';

import http from "../../http-common";

import { Link } from 'react-router-dom';

class Categories extends React.Component {
  // объект state описывает внутреннее состояние компонент (аналог data во Vue.js)
  state = {
    categories: [],
  };

  // обработчик, который срабатывает до вызова render()
  componentDidMount() {
    http
      .get("/categories")
      .then(response => {
        // обновление состояния
        this.setState({ categories: response.data })
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { categories } = this.state;

    let list = [];
    for (let i in categories) {
      list.push(
        <Link to={`/category/${categories[i].id}`} param1={categories[i].id} key={i}>
          <Category key={i} id={categories[i].id} content={categories[i].name}/>
        </Link>
      )
    }
    return <div>
      <Link to={`/addCategory`}>Добавить категорию </Link>
      {list.length > 0 ? list : "Подождите, идёт загрузка данных"}
    </div>
  }
}

export default Categories;