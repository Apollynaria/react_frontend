import React from 'react';

// импорт компонента CategoryData
import User from '../components/user/User';

import http from "../../http-common";

import { Link } from 'react-router-dom';

class Users extends React.Component {
  // объект state описывает внутреннее состояние компонент (аналог data во Vue.js)
  state = {
    users: [],
  };

  // обработчик, который срабатывает до вызова render()
  componentDidMount() {
    http
      .get("/users")
      .then(response => {
        // обновление состояния
        this.setState({ users: response.data })
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { users } = this.state;

    let list = [];
    for (let i in users) {
      list.push(
        <Link to={`/user/${users[i].id}`} param1={users[i].id} key={i}>
          <User key={i} id={users[i].id} content={users[i].name}/>
        </Link>
      )
    }
    return <div>
      <Link to={`/addUser`}>Добавить пользователя </Link>
      {list.length > 0 ? list : "Подождите, идёт загрузка данных"}
    </div>
  }
}

export default Users;